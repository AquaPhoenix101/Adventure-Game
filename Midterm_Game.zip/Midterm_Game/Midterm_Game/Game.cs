﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_Game
{
    public class Game
    {
        public void Run()
        {
            Console.WriteLine("Welcome Creator! Are you ready to make a new forest?\n Press Enter to Continue.");
            Console.ReadLine();

            Console.Clear();
            
            Console.WriteLine("Creator, it's time to make a new forest. There are many things to do.\n You must decide the inhabitants of this new domain.");
            Console.ReadLine();
        }
    }
}
